import React from 'react'

export default function DashboardEventAdmin() {
  return (
    <div>DashboardEventAdmin</div>
  )
}
