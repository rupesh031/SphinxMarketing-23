import React, { useState } from "react";
import create from "../../../../images/create_event.png";
function UserProfile() {
  // const [tabactive, settab] = useState("All Events");

  return (
    <div className="user-event">
      <div className="user-title">User Profile</div>
      <div className="user-tabmenu">
        <div className="tab-function">
          
        </div>
      </div>
      <div className="tab-line"></div>
    </div>
  );
}

export default UserProfile;
