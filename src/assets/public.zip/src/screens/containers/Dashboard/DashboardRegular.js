import React from 'react'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import SidebarUser from "../../components/Sidebar";
import Profile from './DashboardRegular/Profile';
import UserProfile from './DashboardRegular/UserProfile';

export default function DashboardRegular() {
  const Sdata = {
    title: "User Login",
    options: ["Profile", "Events", "Passes", "Complaints"],
  };
  return (
    <div>
      <div className="space-top"></div>
      <SidebarUser data={Sdata} />
      <div className="user-main">
        <UserProfile />
        <Profile />
      </div>
    </div>
  );
}
