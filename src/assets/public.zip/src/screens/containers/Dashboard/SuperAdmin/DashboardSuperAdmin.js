import React from "react";
import SidebarSuperAdmin from "../../../components/Sidebar";
import EventTab from "./EventTab";
import SuperEvent from "./SuperEvent";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Payment from "../../../components/Payment/payment";


export default function DashboardSuperAdmin() {
  const Sdata = {
    title: "Admin Login",
    options: ["Profile", "Events", "Pass", "Payment", "User Details", "Ambassador"],
  };
  return (
    <div>
      <div className="space-top"></div>
      <SidebarSuperAdmin data={Sdata} />
      <div className="super-main">
        <SuperEvent />
        <EventTab />
      </div>
    </div>
  );
}
