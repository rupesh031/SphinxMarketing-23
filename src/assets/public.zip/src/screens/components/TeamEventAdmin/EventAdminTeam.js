import React from 'react'
import SidebarSuperAdmin from '../Sidebar';
import TeamTab from './TeamTab';

function EventAdminTeam() {
    const Sdata = {
        title: "Event Admin Login",
        options: ["Profile", "Events", "Complaints", "Team"],
      };
      return (
    <div className='eventadmin-team'>
          <div className="space-top"></div>
          <SidebarSuperAdmin data={Sdata} />
          <div className='eventadmin-team-main'>
            <TeamTab />
           
          </div>
        
          </div>
      );
}

export default EventAdminTeam