 const PassData = [
    {
        passId:1,
        passPoster:"images/pass1.png",
        cta:""
    },
    {
        passId:2,
        passPoster:"images/pass2.png",
        cta:""
    },
    {
        passId:3,
        passPoster:"images/pass3.png",
        cta:""
    }
   
]
export{
    PassData
}