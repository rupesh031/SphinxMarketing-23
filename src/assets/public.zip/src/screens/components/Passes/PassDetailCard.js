import { passDetailData} from "./Data";
export default function PassDetailCard(props){
    const onePassDetail = passDetailData[props.passNo]
    return(
        <div className="passDetailCard-main">
            <img className="passDetailCard-img" src = {onePassDetail.poster}></img>
            <p className="passDetailCard-p">
                {
                    onePassDetail.details
                }
            </p>
        </div>
    );
}