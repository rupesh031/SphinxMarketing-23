import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

export default function PassCard(props) {
    const navigate = useNavigate();
    const navigateToPassDetail = () => {
        navigate("/pass1");
    }
    return (
        <div className="passCard-main">
            <Button onClick={navigateToPassDetail}>
                <img className="passCard-img" src={props.image}>

                </img>

            </Button>
        </div>
    );
}