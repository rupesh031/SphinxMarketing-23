// import { PassData } from "./PassData";
import { PassData } from "./PassData";
import SidebarUser from "../Sidebar";
import "./desktop26.css";
import "./desktop27.css";

import PassCard from "./PassCard";
export default function Passes() {
    const Sdata = {
        title: "User Login",
        options: ["Profile", "Events", "Complaints", "Team"],
    };
    const passCardElements = PassData.map((onePass) => {
        return (
            <PassCard
                key={onePass.passId}
                image={onePass.passPoster}
            />);
    })
    return (
        <div>
            <div className="space-top"></div>
            <SidebarUser data={Sdata} />
            <div className="user-main">
                <div className="desktop26-main">
                    <div className="desktop26-head">
                        <h3>
                            Passes
                        </h3>
                        <button className="desktop26-btn desktop26-create-btn">
                            <div className="desktop26-btn-inner">
                                <img src="images/vector.png"></img>
                                <p>Create Pass</p>
                            </div>
                        </button>
                    </div>


                    {/* <div className="desktop24-border"></div> */}
                    <div className="desktop26-Passes">



                        {passCardElements}

                    </div>

                </div>
            </div>
        </div>

    );
}