import { passDetailData } from "./Data";
import PassDetailCard from "./PassDetailCard";
import { useState } from "react";
import "./desktop26.css";
import "./desktop27.css";

export default function PassDetail() {

    const [inAboutTab, setInAboutTab] = useState(true);
    const [inRegStudentTab, setInRegStudentEventTab] = useState(false);
    const passNo = 0;



    function changeToRegStudentTab() {
        setInRegStudentEventTab(true);
        setInAboutTab(false);
    }
    function changeToAboutTab() {
        setInRegStudentEventTab(false);
        setInAboutTab(true);
    }
    return (
        <div className="desktop27-main">

            <h3 className="desktop27-head">{passDetailData[passNo].heading}</h3>

            <div className="desktop27-tabChangebtn" >
                <button className="desktop27-btn" onClick={changeToAboutTab} style={{ borderBottom: inAboutTab ? "2px solid blue" : "none", color: !inAboutTab ? "rgba(0,0,0,0.6)" : "" }} >About</button>
                <button className="desktop27-btn" onClick={changeToRegStudentTab} style={{ borderBottom: inRegStudentTab ? "2px solid blue" : "none", color: !inRegStudentTab ? "rgba(0,0,0,0.6)" : "" }}>Registered Students</button>
            </div>

            <div className="desktop27-border"></div>


            {inAboutTab && <div className="desktop27-passDetail">
                <PassDetailCard passNo={1} />
            </div>}

        </div>


    );

}