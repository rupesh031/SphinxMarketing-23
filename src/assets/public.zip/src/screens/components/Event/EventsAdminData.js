const allEventsAdminData =  [
    {
        eventId:1,
        eventPoster:"images/eventp1.png",
        cta:""
    },
    {
        eventId:2,
        eventPoster:"images/eventp2.png",
        cta:""
    },
    {
        eventId:3,
        eventPoster:"images/eventp3.png",
        cta:""
    },
    {
        eventId:4,
        eventPoster:"images/eventp4.png",
        cta:""
    }
]

const pastEventsAdminData =  [
    {
        eventId:1,
        eventPoster:"images/eventp1.png",
        cta:""
    },
    {
        eventId:2,
        eventPoster:"images/eventp2.png",
        cta:""
    },
    {
        eventId:3,
        eventPoster:"images/eventp3.png",
        cta:""
    }
   
]
export{
    allEventsAdminData,
    pastEventsAdminData
}