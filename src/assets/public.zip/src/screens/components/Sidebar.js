import React, { useState } from "react";
import toggle from "../../images/toggle.png";
import { Link, NavLink } from "react-router-dom";
import { Button } from "@mui/material";
import { useNavigate } from "react-router-dom";

function SidebarUser(props) {
  const navigate = useNavigate();
  const givePath = (opt) => {
    if (opt == 'Profile') {
      return '/';
    } else {
      return '/' + opt.toLowerCase().replace(" ", "");
    }
  }
  const { data } = props;
  const [isSidebar, SetSidebar] = useState(true);
  const [optactive, setactive] = useState(data.options[0]);
  const sideBarBtnClickHandler = (e) => {
    navigate(givePath(e.target.id));
  }
  const func1 = (isSidebar) => {
    if (isSidebar) {
      return <>
        <div className="sidebar-header" onClick={() => {
          SetSidebar(!isSidebar);
        }}>
          <div className="sidebar-title">{data.title}</div>
          <img
            className={
              isSidebar ? "sidebar-toggle rotate0" : `sidebar-toggle rotate`
            }
            src={toggle}
            onClick={() => {
              SetSidebar(!isSidebar);
            }}
          ></img>
        </div>
      </>
    } else {
      return <>
        <div className="sidebar-closed-img" onClick={() => {
          SetSidebar(!isSidebar);
        }}>
          <img src={require('../../images/sidebar.png')}></img>
        </div>
      </>
    }
  }

  return (
    < div >
      <div className={isSidebar ? "sidebar" : `sidebar sidebar-exit`}>
        {func1(isSidebar)}

        <div className={isSidebar ? "sidebar-options" : `sidebar-options exit`}>
          {data.options.map((opt, i) => (
            <Button className="sidebarBtn" onClick={(e) => {
              setactive(opt);
              sideBarBtnClickHandler(e)
            }}>
              <div
                className={`sidebar-opt`}
                id={opt}
                key={i}
              >
                {opt}
                {optactive === opt ? <div className="sidebar-active"></div> : null}
              </div>
            </Button>
          ))}
        </div>
      </div>
    </div >
  );
}

export default SidebarUser;
