export const first = (payload) => ({
  type: second,
  payload
})
