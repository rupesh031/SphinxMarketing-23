import logo from "./logo.svg";
import "./App.css";
import Navbar from "./screens/components/Navbar";
import DashboardRegular from "./screens/containers/Dashboard/DashboardRegular";
import Passes from "./screens/components/Passes/Passes";
import Footer from "./screens/components/Footer";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import PassDetail from "./screens/components/Passes/Passes";
import EventsParticipate from "./screens/components/Events/eventsParticipate";
// import Queries from "./screens/components/Events/Queries";
import EventAdmin from "./screens/components/Event/EventAdmin";
import MainDesktop14 from './screens/components/Event/MainDesktop14';
import Events_EventAdmin from "./screens/components/EventAdmin_Events/event_EventAdmin";
import { DataDesktop14 } from "./screens/components/Event/DataDesktop14";
import AboutSection from "./screens/components/Event/AboutSection";
import EventAdminTeam from "./screens/components/TeamEventAdmin/EventAdminTeam";

// import Payment from "./screens/components/Payment/payment";
// import UserDetails from "./screens/components/UserDetails/userDetails";
// import Ambassador from "./screens/components/Ambassador/ambassador";

function App() {
  const givePath = (id) => {
    console.log("/events/event" + id);

    return "/events/event" + id;
  }
  return (
    <BrowserRouter>
      <div className="App">
        <Navbar />
        {/* <Events_EventAdmin /> */}
        {/* <EventAdmin />
        <MainDesktop14 /> */}
        {/* <EventAdminTeam /> */}
        {/* <MainDesktop14 id={0} /> */}
        <Routes>
          <Route exact path='/' element={<EventAdmin />} />
          {/* <Route exact path='/' element={<DashboardRegular />} /> */}
          {/* <Route exact path='/passes' element={<Passes />} />
          <Route exact path='/passes/pass1' element={<PassDetail />} />
          <Route exact path='/pass1' element={<PassDetail />} />*/}
          {/* <Route exact path='/events' element={<Events_EventAdmin />} /> */}
          <Route exact path="/events" element={<EventAdmin />} />
          {DataDesktop14.map((e, id) => {
            return <Route exact path={'/event' + (id + 1)} element={<MainDesktop14 id={id} />} />
          })}
          {/* <Route exact path='/event1' element={<MainDesktop14 id={0} />} /> */}
          <Route exact path='/team' element={<EventAdminTeam />} />

          {/* <Route exact path="/events/event1" element={<MainDesktop14 id={1} />} /> */}


        </Routes>
        {/* <Route path='/payment' element={<Payment />} />
          <Route path='/userdetails' element={<UserDetails />} />
          <Route path='/ambassador' element={<Ambassador />} /> */}
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
